# English Sentences > 2025-03-21 4:05pm
https://universe.roboflow.com/capstone-rs6up/english-sentences-pomoo-ojjql

Provided by a Roboflow user
License: MIT

